# 同时收集kucoin和Binance的level2数据
import os
from datetime import datetime
import asyncio
from collections import deque
import csv

from kucoin_futures.client import WsToken
from kucoin_futures.ws_client import KucoinFuturesWsClient

# 定义批量存储的数据队列和当前日期字符串
data_queue = deque()
current_date_str = ""
storage_folder = "/home/ec2-user/HFT_data/Kucoin/level2Depth5"  # 设置存储文件夹的名称
filename = ""

"""
kc数据格式如下:
{
    'bids': [['66208.9', 2257], ['66208.8', 3750], ['66205.5', 661], ['66204.6', 1099], ['66201.1', 1099]], 
    'sequence': 1695754123128, 
    'timestamp': 1713795023900, 
    'ts': 1713795023900,   # 注意是毫秒
    'asks': [['66228.1', 3750], ['66231.4', 3000], ['66231.5', 3750], ['66234.7', 24301], ['66234.8', 3750]]
}

Binance数据格式如下：
{
    'e': 'depthUpdate', # Event type
    'E': 1714457520245, # Event time
    'T': 1714457520243, # Transaction time
    's': 'BTCUSDT', 
    'U': 4520038695868, 
    'u': 4520038701033, 
    'pu': 4520038690253, 
    'b': [['63209.30', '5.772'], ['63209.20', '0.001'], ['63208.80', '0.258'], ['63208.50', '0.020'], ['63208.40', '0.063']], 
    'a': [['63209.40', '0.614'], ['63209.50', '0.775'], ['63209.60', '0.018'], ['63209.70', '0.002'], ['63210.00', '0.211']]
}

"""


# 根据时间戳获取UTC日期字符串
def get_date_str_from_ts(ts):
    ts_seconds = int(ts / 1e3)  # 假设ts是纳秒级别的时间戳，转换为秒级时间戳
    date_str = datetime.utcfromtimestamp(ts_seconds).strftime('%Y-%m-%d')
    return date_str


# 创建并初始化CSV文件，包括路径
def create_csv_file(symbol, date_str):
    # 确保存储文件夹存在
    if not os.path.exists(storage_folder):
        os.makedirs(storage_folder)
    filename = os.path.join(storage_folder, f"{symbol}-level2Depth5-{date_str}.csv")
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                'sequence', 'ts',
                'bp1', 'bp2', 'bp3', 'bp4', 'bp5',
                'ap1', 'ap2', 'ap3', 'ap4', 'ap5',
                'bv1', 'bv2', 'bv3', 'bv4', 'bv5',
                'av1', 'av2', 'av3', 'av4', 'av5',
            ])
    return filename


# 将数据写入CSV文件
def flush_data_to_csv(filename, data_to_flush):
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        for data in data_to_flush:
            writer.writerow(data)
        file.flush()


async def main(symbol='ETHUSDTM'):
    global current_date_str
    global filename

    async def deal_msg(msg):
        global current_date_str
        global filename
        data = msg['data']
        ts = data['ts']
        date_str = get_date_str_from_ts(ts)

        # 检查是否跨日
        if date_str != current_date_str:
            if data_queue:  # 如果队列中有数据，先清空队列
                flush_data_to_csv(filename, list(data_queue))
                data_queue.clear()
            filename = create_csv_file(symbol, date_str)  # 创建新的文件
            # print(filename)
            current_date_str = date_str  # 更新当前日期

        bids = data.get('bids')
        asks = data.get('asks')

        # 将新数据加入队列
        data_queue.append([
            # 'sequence', 'ts',
            # 'bp1', 'bp2', 'bp3', 'bp4', 'bp5',
            # 'ap1', 'ap2', 'ap3', 'ap4', 'ap5',
            # 'bv1', 'bv2', 'bv3', 'bv4', 'bv5',
            # 'av1', 'av2', 'av3', 'av4', 'av5',
            data.get('sequence'), ts,
            float(bids[0][0]), float(bids[1][0]), float(bids[2][0]), float(bids[3][0]), float(bids[4][0]),
            float(asks[0][0]), float(asks[1][0]), float(asks[2][0]), float(asks[3][0]), float(asks[4][0]),
            bids[0][1], bids[1][1], bids[2][1], bids[3][1], bids[4][1],
            asks[0][1], asks[1][1], asks[2][1], asks[3][1], asks[4][1],
        ])

    client = WsToken()
    ws_client = await KucoinFuturesWsClient.create(None, client, deal_msg, private=False)
    await ws_client.subscribe(f'/contractMarket/level2Depth5:{symbol}')

    while True:
        # 定期清空队列到当前文件
        if data_queue:
            flush_data_to_csv(filename, list(data_queue))
            data_queue.clear()
        await asyncio.sleep(10)  # 定时检查和写入数据


if __name__ == "__main__":
    symbol = 'ETHUSDTM'  # 设置你想监控的交易对
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(symbol))
