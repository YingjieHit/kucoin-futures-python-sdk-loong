# ASQ高频做市模型
import numpy as np


class AsqModel:
    def __init__(self):
        pass

    @staticmethod
    def get_bid_spread(sigma, A, k, gamma, q):
        var1 = (1 / gamma) * np.log(1 + gamma / k)
        var2 = (2 * float(q) + 1) / 2 * np.sqrt(sigma ** 2 * gamma / (2 * k * A) * (1 + gamma / k) ** (1 + k / gamma))
        return var1 + var2

    @staticmethod
    def get_ask_spread(sigma, A, k, gamma, q):
        var1 = (1 / gamma) * np.log(1 + gamma / k)
        var2 = (2 * float(q) - 1) / 2 * np.sqrt(sigma ** 2 * gamma / (2 * k * A) * (1 + gamma / k) ** (1 + k / gamma))
        return var1 - var2
    

asq_model = AsqModel()
