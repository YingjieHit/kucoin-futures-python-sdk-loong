
import numpy as np
from collections import deque
import time

from algo_utils import algo_utils

# 测试数据长度
n = 1000

# 初始化 NumPy 数组和 deque
np_array = np.random.randn(n)
deq = deque(maxlen=n)

# 插入测试数据
np_array[:] = np.arange(n)
deq.extend(np.arange(n))

def test_numpy():
    global np_array
    np_array[:-1] = np_array[1:]  # 左移
    np_array[-1] = n  # 新数据

def test_deque():
    # deq.popleft()  # 移除最左边
    deq.append(n)  # 添加新数据
    # 转化数据
    np_arr = np.array(deq)

def test_np_roll():
    global np_array
    np_array = np.roll(np_array, -1)
    np_array[-1] = n  # 新数据

def test_autocorrelation():
    global  np_array
    a = algo_utils.cal_autocorrelation(np_array)
    print(f"a: {a}")

# 性能测试
start_time = time.time()
for _ in range(10000):
    test_numpy()
print("NumPy time:", (time.time() - start_time)*1000/10000, "ms")

start_time = time.time()
for _ in range(10000):
    test_deque()
print("Deque time:", (time.time() - start_time)*1000/10000, "ms")

start_time = time.time()
for _ in range(10000):
    test_np_roll()
print("Numpy roll time:", (time.time() - start_time)*1000/10000, "ms")

start_time = time.time()
# for _ in range(10000):
test_autocorrelation()
print("自相关计算 time:", (time.time() - start_time)*1000/10000, "ms")
