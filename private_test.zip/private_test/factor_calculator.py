# 实盘因子计算（不使用pandas）

import numpy as np

from private_object import AggTickerSer, AggTicker
from algo_utils import algo_utils


class FactorCalculator:
    def __init__(self, agg_ticker_ser: AggTickerSer, max_size=360):
        self.agg_ticker_ser = agg_ticker_ser
        self.factor_size = 0
        self.max_size = max_size

        self.feature_names = [
            'vol_imb',
            'ema5_vol_imb', 'ema10_vol_imb', 'ema20_vol_imb',
            'vol_imb_std10', 'vol_imb_std20', 'vol_imb_std30', 'vol_imb_std50', 'vol_imb_std120',
            'ret_b_1s', 'ret_b_10s',
            'ret_b_1s_std60', 'ret_b_1s_std120', # 'ret_b_1s_std360',
            'ret_b_1s_sharpe60', 'ret_b_1s_sharpe120', # 'ret_b_1s_sharpe360',
            'ask_ret_10s', 'bid_ret_10s', 'ask_ret_120s', 'bid_ret_120s',
        ]

        # 初始化因子数组
        # mid_price
        self.mid_price = np.ones(max_size, dtype=np.float64)

        self.vol_imb = np.ones(max_size, dtype=np.float64)

        # 非因子，辅助计算因子
        self.bv_sum_ema5 = np.ones(max_size, dtype=np.float64)
        self.bv_sum_ema10 = np.ones(max_size, dtype=np.float64)
        self.bv_sum_ema20 = np.ones(max_size, dtype=np.float64)
        self.av_sum_ema5 = np.ones(max_size, dtype=np.float64)
        self.av_sum_ema10 = np.ones(max_size, dtype=np.float64)
        self.av_sum_ema20 = np.ones(max_size, dtype=np.float64)

        # 因子
        self.ema5_vol_imb = np.ones(max_size, dtype=np.float64)
        self.ema10_vol_imb = np.ones(max_size, dtype=np.float64)
        self.ema20_vol_imb = np.ones(max_size, dtype=np.float64)

        # 因子
        self.vol_imb_std10 = np.ones(max_size, dtype=np.float64)
        self.vol_imb_std20 = np.ones(max_size, dtype=np.float64)
        self.vol_imb_std30 = np.ones(max_size, dtype=np.float64)
        self.vol_imb_std50 = np.ones(max_size, dtype=np.float64)
        self.vol_imb_std120 = np.ones(max_size, dtype=np.float64)

        # 因子
        self.ret_b_1s = np.ones(max_size, dtype=np.float64)
        self.ret_b_10s = np.ones(max_size, dtype=np.float64)

        self.ret_b_1s_std60 = np.ones(max_size, dtype=np.float64)
        self.ret_b_1s_std120 = np.ones(max_size, dtype=np.float64)
        # self.ret_b_1s_std360 = np.ones(max_size, dtype=np.float64)

        self.ret_b_1s_sharpe60 = np.ones(max_size, dtype=np.float64)
        self.ret_b_1s_sharpe120 = np.ones(max_size, dtype=np.float64)
        # self.ret_b_1s_sharpe360 = np.ones(max_size, dtype=np.float64)

        self.ask_ret_10s = np.ones(max_size, dtype=np.float64)
        self.bid_ret_10s = np.ones(max_size, dtype=np.float64)
        self.ask_ret_120s = np.ones(max_size, dtype=np.float64)
        self.bid_ret_120s = np.ones(max_size, dtype=np.float64)

    # 因子数组左移一位
    def factor_shift_left(self):
        self.mid_price[:-1] = self.mid_price[1:]

        self.vol_imb[:-1] = self.vol_imb[1:]

        self.bv_sum_ema5[:-1] = self.bv_sum_ema5[1:]
        self.bv_sum_ema10[:-1] = self.bv_sum_ema10[1:]
        self.bv_sum_ema20[:-1] = self.bv_sum_ema20[1:]
        self.av_sum_ema5[:-1] = self.av_sum_ema5[1:]
        self.av_sum_ema10[:-1] = self.av_sum_ema10[1:]
        self.av_sum_ema20[:-1] = self.av_sum_ema20[1:]

        self.ema5_vol_imb[:-1] = self.ema5_vol_imb[1:]
        self.ema10_vol_imb[:-1] = self.ema10_vol_imb[1:]
        self.ema20_vol_imb[:-1] = self.ema20_vol_imb[1:]

        self.vol_imb_std10[:-1] = self.vol_imb_std10[1:]
        self.vol_imb_std20[:-1] = self.vol_imb_std20[1:]
        self.vol_imb_std30[:-1] = self.vol_imb_std30[1:]
        self.vol_imb_std50[:-1] = self.vol_imb_std50[1:]
        self.vol_imb_std120[:-1] = self.vol_imb_std120[1:]

        self.ret_b_1s[:-1] = self.ret_b_1s[1:]
        self.ret_b_10s[:-1] = self.ret_b_10s[1:]

        self.ret_b_1s_std60[:-1] = self.ret_b_1s_std60[1:]
        self.ret_b_1s_std120[:-1] = self.ret_b_1s_std120[1:]
        # self.ret_b_1s_std360[:-1] = self.ret_b_1s_std360[1:]
        self.ret_b_1s_sharpe60[:-1] = self.ret_b_1s_sharpe60[1:]
        self.ret_b_1s_sharpe120[:-1] = self.ret_b_1s_sharpe120[1:]
        # self.ret_b_1s_sharpe360[:-1] = self.ret_b_1s_sharpe360[1:]

        self.ask_ret_10s[:-1] = self.ask_ret_10s[1:]
        self.bid_ret_10s[:-1] = self.bid_ret_10s[1:]
        self.ask_ret_120s[:-1] = self.ask_ret_120s[1:]
        self.bid_ret_120s[:-1] = self.bid_ret_120s[1:]

    def get_features(self):
        # 获取基础数据的时间序列
        ser = self.agg_ticker_ser
        # 每次计算因子前，将因子数组左移一位
        self.factor_shift_left()

        # codedium的这个想法有点好？
        # vol_imb = np.log(self.agg_ticker_manager.agg_ticker.av_last / self.agg_ticker_manager.agg_ticker.bv_last)
        # self.vol_imb_ema300[-1] = self.vol_imb[-1] - self.vol_imb.ewm(span=300).mean()  

        # 计算mid_price
        self.mid_price[-1] = (ser.bp_last[-1] + ser.ap_last[-1]) / 2

        # 挂单量不平衡因子
        self.vol_imb[-1] = (ser.bv_last[-1] - ser.av_last[-1]) / (ser.bv_last[-1] + ser.av_last[-1])

        # 一定时间指数平均挂单量不平衡
        self.bv_sum_ema5[-1] = algo_utils.cal_ema_fast(ser.bv_sum[-1], self.bv_sum_ema5[-2], 5, step=self.factor_size)
        self.bv_sum_ema10[-1] = algo_utils.cal_ema_fast(ser.bv_sum[-1], self.bv_sum_ema10[-2], 10,
                                                        step=self.factor_size)
        self.bv_sum_ema20[-1] = algo_utils.cal_ema_fast(ser.bv_sum[-1], self.bv_sum_ema20[-2], 20,
                                                        step=self.factor_size)
        self.av_sum_ema5[-1] = algo_utils.cal_ema_fast(ser.av_sum[-1], self.av_sum_ema5[-2], 5, step=self.factor_size)
        self.av_sum_ema10[-1] = algo_utils.cal_ema_fast(ser.av_sum[-1], self.av_sum_ema10[-2], 10,
                                                        step=self.factor_size)
        self.av_sum_ema20[-1] = algo_utils.cal_ema_fast(ser.av_sum[-1], self.av_sum_ema20[-2], 20,
                                                        step=self.factor_size)

        self.ema5_vol_imb[-1] = (self.bv_sum_ema5[-1] - self.av_sum_ema5[-1]) / (
                self.bv_sum_ema5[-1] + self.av_sum_ema5[-1])
        self.ema10_vol_imb[-1] = (self.bv_sum_ema10[-1] - self.av_sum_ema10[-1]) / (
                self.bv_sum_ema10[-1] + self.av_sum_ema10[-1])
        self.ema20_vol_imb[-1] = (self.bv_sum_ema20[-1] - self.av_sum_ema20[-1]) / (
                self.bv_sum_ema20[-1] + self.av_sum_ema20[-1])

        # vol_imb的标准差
        self.vol_imb_std10[-1] = np.std(self.vol_imb[-10:])
        self.vol_imb_std20[-1] = np.std(self.vol_imb[-20:])
        self.vol_imb_std30[-1] = np.std(self.vol_imb[-30:])
        self.vol_imb_std50[-1] = np.std(self.vol_imb[-50:])
        self.vol_imb_std120[-1] = np.std(self.vol_imb[-120:])

        # 过去时间窗口的收益率 ret_b
        self.ret_b_1s[-1] = (self.mid_price[-1] - self.mid_price[-2]) / self.mid_price[-2]
        self.ret_b_10s[-1] = (self.mid_price[-1] - self.mid_price[-11]) / self.mid_price[-11]

        # ret_b_1s的标准差
        self.ret_b_1s_std60[-1] = np.std(self.ret_b_1s[-60:])
        self.ret_b_1s_std120[-1] = np.std(self.ret_b_1s[-120:])
        # self.ret_b_1s_std360[-1] = np.std(self.ret_b_1s[-360:])

        # ret_b_1s的sharpe
        self.ret_b_1s_sharpe60[-1] = self.ret_b_1s[-60:].mean() / self.ret_b_1s_std60[-1]
        self.ret_b_1s_sharpe120[-1] = self.ret_b_1s[-120:].mean() / self.ret_b_1s_std120[-1]
        # self.ret_b_1s_sharpe360[-1] = self.ret_b_1s[-360:].mean() / self.ret_b_1s_std360[-1]

        # ask和bid在过去一段时间的收益率
        self.ask_ret_10s[-1] = ser.ap_last[-1] / ser.ap_last[-11] - 1
        self.bid_ret_10s[-1] = ser.bp_last[-1] / ser.bp_last[-11] - 1
        self.ask_ret_120s[-1] = ser.ap_last[-1] / ser.ap_last[-121] - 1
        self.bid_ret_120s[-1] = ser.bp_last[-1] / ser.bp_last[-121] - 1
        

        # 记录因子数组的长度
        if self.factor_size < self.max_size:
            self.factor_size += 1

        factors = np.array([
            self.vol_imb[-1], 
            self.ema5_vol_imb[-1], self.ema10_vol_imb[-1], self.ema20_vol_imb[-1],
            self.vol_imb_std10[-1], self.vol_imb_std20[-1], self.vol_imb_std30[-1], self.vol_imb_std50[-1], self.vol_imb_std120[-1],
            self.ret_b_1s[-1], self.ret_b_10s[-1],
            self.ret_b_1s_std60[-1], self.ret_b_1s_std120[-1], 
            self.ret_b_1s_sharpe60[-1], self.ret_b_1s_sharpe120[-1], 
            self.ask_ret_10s[-1], self.bid_ret_10s[-1], self.ask_ret_120s[-1], self.bid_ret_120s[-1],
        
        ])
        return factors
