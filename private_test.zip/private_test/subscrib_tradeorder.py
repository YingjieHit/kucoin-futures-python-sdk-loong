import asyncio
import socket
# from kucoin.client import WsToken
# from kucoin.ws_client import KucoinWsClient

from kucoin_futures.client import WsToken
from kucoin_futures.ws_client import KucoinFuturesWsClient


async def main():
    async def deal_msg(msg):
        print(msg["data"])
        pass

    # is private
    client = WsToken(key='65bb0ff628c3e4000110223d',
                     secret='c393864f-fc45-461d-a199-8d52c10978c0',
                     passphrase='api_4321',
                     url='https://api-futures.kucoin.com')

    # sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    # address = ('api-futures.kucoin.com', 443)
    # sock.connect(address)

    ws_client = await KucoinFuturesWsClient.create(None, client, deal_msg, private=True)  # , sock=sock)
    await ws_client.subscribe('/contractMarket/tradeOrders')

    while True:
        await asyncio.sleep(60)


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
