# 算法工具

import numpy as np
from statsmodels.tsa.stattools import acf


class AlgoUtils:
    
    # 计算指数移动平均的快速方法：根据前ema值、当前值、窗口长度
    @staticmethod
    def cal_ema_fast(cur: float, pre_ema: float, span: int, step: int):
        if step == 0:
            # 如果是第一次，直接返回当前值
            return cur
        alpha = 2 / (span + 1)
        return cur * alpha + pre_ema * (1 - alpha)
    
    # 计算指数移动平均（非快速）: 根据输入序列和窗口长度
    @staticmethod
    def cal_ema(arr: float,  span: int):
        # 计算指数移动平均
        alpha = 2 / (span + 1)
        ema = arr[0]  # 初始化EMA为序列的第一个数据点
        for value in arr[1:]:
            ema = alpha * value + (1 - alpha) * ema
        return ema
    
    # 计算自相关系数
    @staticmethod
    def cal_autocorrelation(ftc_ser: np.array, nlags: int = 10):
        auto_correlations = acf(ftc_ser, nlags=nlags, fft=True)
        return auto_correlations

algo_utils = AlgoUtils()
