import asyncio

import numpy as np
from lightgbm import LGBMRegressor
import joblib

from kucoin_futures.strategy.base_market_maker import BaseMarketMaker
from kucoin_futures.strategy.object import Ticker, Order
from kucoin_futures.strategy.utils import utils
from kucoin_futures.common.const import PRICE_INTERVAL
from kucoin_futures.common.app_logger import app_logger

from private_object import AggTickerManager, AggTickerSer
from alpha_factor_calculator import AlphaFactorCalculator
from mm_model.asq_model import ASQModel


class ASQAlphaMMBaseStrategy(BaseMarketMaker):
    def __init__(self, symbol, key, secret, passphrase, lever, open_size, init_second, wait_second, ml_model_path,
                 asq_model_path):
        super().__init__(symbol, key, secret, passphrase)

        # 读取参数
        self.lever = lever  # 使用杠杆
        self.open_size = open_size  # 开仓张数
        self.init_second = init_second  # 预热秒数
        self.wait_second = wait_second  # 不撤单等待秒数
        self.ml_model_path = ml_model_path
        self.asq_model_path = asq_model_path

        # 获取和计算合约信息
        self.price_int = PRICE_INTERVAL[self.symbol]  # 最小跳价
        self.price_decimal_places = utils.calc_decimal_places(self.price_int)  # 计算小数位数

        # 定义变量和对象
        self.agg_ticker_manager = AggTickerManager()  # 聚合ticker管理器
        self.agg_ticker_ser = AggTickerSer(maxlen=1024)  # 聚合ticker序列
        self.factor_calculator = AlphaFactorCalculator(self.agg_ticker_ser, max_size=64)  # 因子计算对象
        self.last_ticker: Ticker | None = None
        self.pos = 0  # 当前持仓纯头寸: 多头-空头
        self.cur_wait_second = 0  # 已经等待的秒数
        self.client_oid_buy = ''  # 当前买单client_oid
        self.client_oid_sell = ''  # 当前卖单client_oid
        self.order_state_buy = 'done'  # 当前买单状态
        self.order_state_sell = 'done'  # 当前卖单状态
        self.schedule_task = None

        self.asq_model: ASQModel | None = joblib.load(self.asq_model_path)  # ASQ模型
        self.lgbm_model: LGBMRegressor = joblib.load(self.ml_model_path)  # LGBM模型

    async def run(self):
        # 创建定时任务
        self.schedule_task = asyncio.create_task(self.schedule_task_process())
        await super().run()

    # 定时任务
    async def schedule_task_process(self):
        while True:
            await asyncio.sleep(60*60)
            try:
                self.asq_model = joblib.load(self.asq_model_path)
                await app_logger.info(f"load asq model success")
                self.lgbm_model = joblib.load(self.ml_model_path)
                await app_logger.info(f"load ml model success")
            except Exception as e:
                await app_logger.error(f"load model failed: {e}")

    async def on_tick(self, ticker: Ticker):
        # 更新agg_ticker数据
        self.agg_ticker_manager.update_ticker(ticker)
        # 整秒时，推送数据（ts为纳秒时间戳）
        if (self.last_ticker is not None) and (ticker.ts // 1e9 != self.last_ticker.ts // 1e9):
            # 读取数据
            new_agg_ticker = self.agg_ticker_manager.agg_ticker
            self.agg_ticker_manager.re_set()

            # 最新ticker放入时间序列中
            self.agg_ticker_ser.update_agg_ticker(new_agg_ticker)

            # 计算因子  TODO: 换成新的因子计算方法
            factors = self.factor_calculator.get_features()

            # 判断数据是否预热完成
            if self.agg_ticker_ser.ser_len >= self.init_second:
                # 计算mid_price
                mid_price = (new_agg_ticker.bp_last + new_agg_ticker.ap_last) / 2
                # 预测收益率
                pre_ret = self.lgbm_model.predict(np.array([factors]))[0]
                # 计算预测后的价格
                pre_mid_price = mid_price * (1 + pre_ret)

                # 计算ASQ模型
                buy_price = pre_mid_price - self.asq_model.get_bid_spread(self.q)
                sell_price = pre_mid_price + self.asq_model.get_ask_spread(self.q)

                # 去除价格多余位
                buy_price = np.ceil(buy_price / self.price_int) * self.price_int
                sell_price = np.floor(sell_price / self.price_int) * self.price_int
                # 防止价格偶然失真
                buy_price = utils.insure_decimals(buy_price, self.price_decimal_places)
                sell_price = utils.insure_decimals(sell_price, self.price_decimal_places)
                # 如果计算的挂单bid_price高于真实bid_price，则调整为真实bid_price
                if buy_price > ticker.bid_price:
                    buy_price = ticker.bid_price
                # 如果计算的挂单ask_price低于真实ask_price，则调整为真实ask_price
                if sell_price < ticker.ask_price:
                    sell_price = ticker.ask_price

                # # 输出价格和要挂单的价格  TODO: 这里仅仅是测试用，需要注释
                # print(f"当前: bid_price: {ticker.bid_price}, ask_price: {ticker.ask_price}")
                # print(f"下单: buy_price: {buy_price}, sell_price: {sell_price}")
                # print("")
                print(f"等待时间{self.cur_wait_second}, self.wait_second{self.wait_second}, 倒计时{self.wait_second - self.cur_wait_second}")


                # 如果等待时间到了或者已经全部成交，则撤销之前未成交的单子，下单,等待时间清零  TODO: 如果因postonly被撤单则重新挂单(该功能不紧急)
                if self.cur_wait_second >= self.wait_second or self.is_all_order_done:
                    # 取消未成交的单子
                    await self.cancel_unfilled_order()
                    # 下单
                    if self.q <= -self.asq_model.Q:
                        self.client_oid_buy = utils.create_client_oid()
                        self.order_state_buy = 'open'
                        await self.create_order(symbol=self.symbol, side='buy', size=self.open_size, type='limit',
                                                price=buy_price, lever=self.lever, client_oid=self.client_oid_buy,
                                                post_only=True)
                    elif self.q >= self.asq_model.Q:
                        self.client_oid_sell = utils.create_client_oid()
                        self.order_state_sell = 'open'
                        await self.create_order(symbol=self.symbol, side='sell', size=self.open_size, type='limit',
                                                price=sell_price, lever=self.lever, client_oid=self.client_oid_sell,
                                                post_only=True)
                    else:
                        self.client_oid_buy = utils.create_client_oid()
                        self.client_oid_sell = utils.create_client_oid()
                        self.order_state_buy = 'open'
                        self.order_state_sell = 'open'
                        await self.create_market_maker_order(symbol=self.symbol, lever=self.lever, size=self.open_size,
                                                             price_buy=buy_price, price_sell=sell_price,
                                                             client_oid_buy=self.client_oid_buy,
                                                             client_oid_sell=self.client_oid_sell,
                                                             post_only=True)
                    # 等待时间清零
                    self.cur_wait_second = 0
                # 更新等待时间
                self.cur_wait_second += 1
            else:
                await app_logger.info(f"等待预热{self.init_second - self.agg_ticker_ser.ser_len}s")
        # 记录为上一个ticker
        self.last_ticker = ticker

    # 撤销未成交的订单
    async def cancel_unfilled_order(self):
        if self.order_state_buy != 'done':
            await self.cancel_order_by_client_oid(self.symbol, self.client_oid_buy)
        if self.order_state_sell != 'done':
            await self.cancel_order_by_client_oid(self.symbol, self.client_oid_sell)

    async def on_order(self, order: Order):
        # 记录仓位
        if order.type == 'match':
            match_size = order.match_size if order.side == 'buy' else -order.match_size
            self.pos += match_size

        # 记录取消订单
        if order.type == 'canceled':
            print(f"订单已取消: {order}")

        # 记录订单状态, 只记录成交或者取消订单
        # if order.status == 'done' or order.type == 'canceled':
        if order.client_oid == self.client_oid_buy:
            self.order_state_buy = order.status
        elif order.client_oid == self.client_oid_sell:
            self.order_state_sell = order.status

        # # TODO: 测试成功后此处应该注释
        # await app_logger.info(f"on_order: {order}")
        # await app_logger.info(f"self.pos: {self.pos}, pos_q: {self.q}")

    # 判断是否没有单子等待成交
    @property
    def is_all_order_done(self):
        return self.order_state_buy == 'done' and self.order_state_sell == 'done'

    # 库存 = pos / open_size
    @property
    def q(self):
        return self.pos / self.open_size
