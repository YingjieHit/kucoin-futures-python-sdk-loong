import asyncio
import time
from kucoin_futures.trade.async_trade import TradeDataAsync


async def main():
    trade = TradeDataAsync(
        key='65bb0ff628c3e4000110223d',
        secret='c393864f-fc45-461d-a199-8d52c10978c0',
        passphrase='api_4321'
    )

    symbol = 'ETHUSDTM'
    side = 'sell'
    lever = 1
    size = 3
    price = 3111.53
    client_id = trade.return_unique_id
    post_only = True

    # res = await trade.create_limit_order(symbol, side, lever, size, price, clientOid=client_id, postOnly=post_only)
    res = await trade.create_market_order(symbol, size, side, lever)
    # price_buy = 3100
    # price_sell = 3600
    # res = await trade.create_market_maker_order(symbol, lever, size, 3000, 3200)  # market maker单

    # res = await trade.cancel_all_limit_order(symbol)
    print(res)


if __name__ == '__main__':
    asyncio.run(main())
