class Subject:
    """订阅到的主题"""
    tickerV2 = 'tickerV2'
    symbolOrderChange = 'symbolOrderChange'



