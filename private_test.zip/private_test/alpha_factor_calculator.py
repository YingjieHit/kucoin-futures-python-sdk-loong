# 实盘因子计算（不使用pandas）

import numpy as np

from private_object import AggTickerSer, AggTicker
from algo_utils import algo_utils


class AlphaFactorCalculator:
    def __init__(self, agg_ticker_ser: AggTickerSer, max_size=360):
        self.agg_ticker_ser = agg_ticker_ser
        self.factor_size = 0
        self.max_size = max_size

        self.feature_names = [
            'vol_imb',
        ]

        # 初始化因子数组
        # mid_price
        self.mid_price = np.ones(max_size, dtype=np.float64)

        self.vol_imb = np.ones(max_size, dtype=np.float64)

    # 因子数组左移一位
    def factor_shift_left(self):
        self.mid_price[:-1] = self.mid_price[1:]

        self.vol_imb[:-1] = self.vol_imb[1:]

    def get_features(self):
        # 获取基础数据的时间序列
        ser = self.agg_ticker_ser
        # 每次计算因子前，将因子数组左移一位
        self.factor_shift_left()

        # 计算mid_price
        self.mid_price[-1] = (ser.bp_last[-1] + ser.ap_last[-1]) / 2

        # 挂单量不平衡因子
        self.vol_imb[-1] = (ser.bv_last[-1] - ser.av_last[-1]) / (ser.bv_last[-1] + ser.av_last[-1])

        # 记录因子数组的长度
        if self.factor_size < self.max_size:
            self.factor_size += 1

        factors = np.array([
            self.vol_imb[-1],
        ])
        return factors
