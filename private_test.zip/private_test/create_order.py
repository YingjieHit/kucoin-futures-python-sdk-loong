from kucoin_futures.trade.trade import TradeData


def main():
    trade = TradeData(
        key='65bb0ff628c3e4000110223d',
        secret='c393864f-fc45-461d-a199-8d52c10978c0',
        passphrase='api_4321',
    )

    symbol = 'ETHUSDTM'
    side = 'buy'
    lever = 1
    size = 1
    price = 3000
    client_id = trade.return_unique_id
    post_only = True
    # 下单
    # res = trade.create_limit_order(symbol, side, lever, size, price, clientOid=client_id, postOnly=post_only)
    res = trade.create_market_order(symbol, side, lever)

    # res = trade.cancel_all_limit_order(symbol)
    print(res)


if __name__ == '__main__':
    main()
