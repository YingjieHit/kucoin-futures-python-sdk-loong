from dataclasses import dataclass

import numpy as np

from kucoin_futures.strategy.object import Ticker


@dataclass
class AggTicker:
    """agg_ticker数据字段"""
    symbol: str
    sequence_first: int
    sequence_last: int

    ap_first: float
    ap_max: float
    ap_min: float
    ap_last: float

    bp_first: float
    bp_max: float
    bp_min: float
    bp_last: float

    av_first: float
    av_max: float
    av_min: float
    av_last: float
    av_sum: float

    bv_first: float
    bv_max: float
    bv_min: float
    bv_last: float
    bv_sum: float

    ts_start: int
    ts_end: int


class AggTickerManager(object):
    def __init__(self):
        self.agg_ticker: AggTicker | None = None
        # self.last_ticker: Ticker | None = None

    def update_ticker(self, ticker: Ticker):
        if self.agg_ticker is None:
            self.agg_ticker = AggTicker(
                symbol=ticker.symbol,
                sequence_first=ticker.sequence,
                sequence_last=ticker.sequence,
                ap_first=ticker.ask_price,
                ap_max=ticker.ask_price,
                ap_min=ticker.ask_price,
                ap_last=ticker.ask_price,
                bp_first=ticker.bid_price,
                bp_max=ticker.bid_price,
                bp_min=ticker.bid_price,
                bp_last=ticker.bid_price,
                av_first=ticker.ask_size,
                av_max=ticker.ask_size,
                av_min=ticker.ask_size,
                av_last=ticker.ask_size,
                av_sum=ticker.ask_size,
                bv_first=ticker.bid_size,
                bv_max=ticker.bid_size,
                bv_min=ticker.bid_size,
                bv_last=ticker.bid_size,
                bv_sum=ticker.bid_size,
                ts_start=ticker.ts,
                ts_end=ticker.ts,
            )
        
        else:
            self.agg_ticker.sequence_last = ticker.sequence
            self.agg_ticker.ap_max = max(ticker.ask_price, self.agg_ticker.ap_max)
            self.agg_ticker.ap_min = min(ticker.ask_price, self.agg_ticker.ap_min)
            self.agg_ticker.ap_last = ticker.ask_price
            self.agg_ticker.bp_max = max(ticker.bid_price, self.agg_ticker.bp_max)
            self.agg_ticker.bp_min = min(ticker.bid_price, self.agg_ticker.bp_min)
            self.agg_ticker.bp_last = ticker.bid_price
            self.agg_ticker.av_max = max(ticker.ask_size, self.agg_ticker.av_max)
            self.agg_ticker.av_min = min(ticker.ask_size, self.agg_ticker.av_min)
            self.agg_ticker.av_last = ticker.ask_size
            self.agg_ticker.av_sum += ticker.ask_size
            self.agg_ticker.bv_max = max(ticker.bid_size, self.agg_ticker.bv_max)
            self.agg_ticker.bv_min = min(ticker.bid_size, self.agg_ticker.bv_min)
            self.agg_ticker.bv_last = ticker.bid_size
            self.agg_ticker.bv_sum += ticker.bid_size
            self.agg_ticker.ts_end = ticker.ts

    def re_set(self):
        self.agg_ticker = None


# 用于管理agg_ticker序列
class AggTickerSer(object):

    def __init__(self, maxlen:int=1024) -> None:
        self.ser_len = 0
        self.max_len = maxlen

        self.ap_first = np.ones(maxlen, dtype=np.float64)
        self.ap_max = np.ones(maxlen, dtype=np.float64)
        self.ap_min = np.ones(maxlen, dtype=np.float64)
        self.ap_last = np.ones(maxlen, dtype=np.float64)
        
        self.bp_first = np.ones(maxlen, dtype=np.float64)
        self.bp_max = np.ones(maxlen, dtype=np.float64)
        self.bp_min = np.ones(maxlen, dtype=np.float64)
        self.bp_last = np.ones(maxlen, dtype=np.float64)
        
        self.av_first = np.ones(maxlen, dtype=np.float64)
        self.av_max = np.ones(maxlen, dtype=np.float64)
        self.av_min = np.ones(maxlen, dtype=np.float64)
        self.av_last = np.ones(maxlen, dtype=np.float64)
        self.av_sum = np.ones(maxlen, dtype=np.float64)

        self.bv_first = np.ones(maxlen, dtype=np.float64)
        self.bv_max = np.ones(maxlen, dtype=np.float64)
        self.bv_min = np.ones(maxlen, dtype=np.float64)
        self.bv_last = np.ones(maxlen, dtype=np.float64)
        self.bv_sum = np.ones(maxlen, dtype=np.float64)

        self.ts_first = np.ones(maxlen, dtype=np.float64)
        self.ts_last = np.ones(maxlen, dtype=np.float64)


    def update_agg_ticker(self, agg_ticker: AggTicker):
        # 数据左移
        self.ap_first[:-1] = self.ap_first[1:]
        self.ap_max[:-1] = self.ap_max[1:]
        self.ap_min[:-1] = self.ap_min[1:]
        self.ap_last[:-1] = self.ap_last[1:]

        self.bp_first[:-1] = self.bp_first[1:]
        self.bp_max[:-1] = self.bp_max[1:]
        self.bp_min[:-1] = self.bp_min[1:]
        self.bp_last[:-1] = self.bp_last[1:]

        self.av_first[:-1] = self.av_first[1:]
        self.av_max[:-1] = self.av_max[1:]
        self.av_min[:-1] = self.av_min[1:]
        self.av_last[:-1] = self.av_last[1:]
        self.av_sum[:-1] = self.av_sum[1:]

        self.bv_first[:-1] = self.bv_first[1:]
        self.bv_max[:-1] = self.bv_max[1:]
        self.bv_min[:-1] = self.bv_min[1:]
        self.bv_last[:-1] = self.bv_last[1:]
        self.bv_sum[:-1] = self.bv_sum[1:]

        self.ts_first[:-1] = self.ts_first[1:]
        self.ts_last[:-1] = self.ts_last[1:]

        # 添加新数据
        self.ap_first[-1] = agg_ticker.ap_first
        self.ap_max[-1] = agg_ticker.ap_max
        self.ap_min[-1] = agg_ticker.ap_min
        self.ap_last[-1] = agg_ticker.ap_last

        self.bp_first[-1] = agg_ticker.bp_first
        self.bp_max[-1] = agg_ticker.bp_max
        self.bp_min[-1] = agg_ticker.bp_min
        self.bp_last[-1] = agg_ticker.bp_last

        self.av_first[-1] = agg_ticker.av_first
        self.av_max[-1] = agg_ticker.av_max
        self.av_min[-1] = agg_ticker.av_min
        self.av_last[-1] = agg_ticker.av_last
        self.av_sum[-1] = agg_ticker.av_sum

        self.bv_first[-1] = agg_ticker.bv_first
        self.bv_max[-1] = agg_ticker.bv_max
        self.bv_min[-1] = agg_ticker.bv_min
        self.bv_last[-1] = agg_ticker.bv_last
        self.bv_sum[-1] = agg_ticker.bv_sum

        self.ts_first[-1] = agg_ticker.ts_start
        self.ts_last[-1] = agg_ticker.ts_end

        # 记录数据长度
        if self.ser_len < self.max_len:
            self.ser_len += 1

