import numpy as np
import scipy
import pandas as pd


# ASQ做市模型，不是机器学习模型
class ASQModel:
    def __init__(self, Q=3, gamma=0.06):
        self.Q = Q
        self.gamma = gamma
        self.sigma = None
        self.A = None
        self.k = None

    def fit(self, data: pd.DataFrame, price_int: float):
        data = data.copy(deep=True)
        # 已经采样完毕，故不需要重采样
        # 1. 估计当前每条数据平均多少时间，用于估计交易时间  输入的ts单位为ms
        start_ts, end_ts = data['ts', 'last'].iloc[0], data['ts', 'last'].iloc[-1]
        # 平均成交时间 = 总时间 / (交易次数)
        ave_time = (end_ts - start_ts) / data['trade_num', 'sum'].sum()  # 此处单位为ms

        # 2. 波动率
        # TODO: 此处未来考虑使用 price model做研究
        data['mid'] = (data['ap1', 'last'] + data['bp1', 'last']) / 2
        # TODO: 未来考虑不使用真实trade估算，而是用orderbook的变化(狙击其他做市商)
        sigma = np.log(data['mid']).diff().std() * np.sqrt((end_ts - start_ts) / ave_time)  # 用对数收益率计算波动率

        # 3. 计算每2个时间间隔的收益率
        # TODO: 这部的目的是展示用，暂时省略

        # 4. 市价单到达速率参数
        A, k = self._fit_market_speed(data, price_int)

        self.sigma = sigma
        self.A = A
        self.k = k
        return sigma, A, k

    def _fit_market_speed(self, data: pd.DataFrame, price_int: float):
        deltalist = np.linspace(price_int, price_int * 10, 10)
        deltadict = {}

        # 分别计算在1-10个ticksize上的市价单到达速度
        for delta in deltalist:
            price_interval = delta
            ask_limit_order_hit = data[('ap1', 'max')].shift(-1) > (data[('ap1', 'last')] + price_interval)
            bid_limit_order_hit = data[('bp1', 'min')].shift(-1) < (data[('bp1', 'last')] - price_interval)
            limit_order_hit = (ask_limit_order_hit | bid_limit_order_hit).astype(int)
            deltas = pd.Series(limit_order_hit[limit_order_hit == 1].index).diff().apply(lambda x: x / 10)
            deltadict[delta] = deltas

        lambdas = pd.DataFrame([[key, 1 / deltadict[key].mean()] for key in deltadict.keys()],
                               columns=['delta', 'lambda_delta']).set_index('delta')

        # 市价单到达速度的方程是y = A * exp(-k * x)，其中x是距离中间价的tick_size数量，范围是1-10的整数；y是在每个x的位置上的成交次数；A, k是我们要的参数
        def exp_fit(x, a, b):
            y = a * np.exp(-b * x)
            return y

        paramsB, cv = scipy.optimize.curve_fit(exp_fit, np.array(lambdas.index),
                                               np.array(lambdas['lambda_delta'].values))
        A, k = paramsB
        return A, k

    def get_bid_spread(self, q):
        var1 = (1 / self.gamma) * np.log(1 + self.gamma / self.k)
        var2 = (2 * q + 1) / 2 * np.sqrt(
            self.sigma ** 2 * self.gamma / (2 * self.k * self.A) * (1 + self.gamma / self.k) ** (
                        1 + self.k / self.gamma))
        return var1 + var2

    def get_ask_spread(self, q):
        var1 = (1 / self.gamma) * np.log(1 + self.gamma / self.k)
        var2 = (2 * q - 1) / 2 * np.sqrt(
            self.sigma ** 2 * self.gamma / (2 * self.k * self.A) * (1 + self.gamma / self.k) ** (
                        1 + self.k / self.gamma))
        return var1 - var2

    @property
    def params(self):
        return self.sigma, self.A, self.k
