import asyncio

import joblib
import numpy as np
from lightgbm import LGBMRegressor
from kucoin_futures.strategy.base_market_maker import BaseMarketMaker
from kucoin_futures.common.app_logger import app_logger
# from kucoin_futures.strategy.utils import utils
from config import SB2_APIKEY, ERROR_LOG_PATH, INFO_LOG_PATH
from kucoin_futures.strategy.object import Ticker, Order
from private_object import AggTickerManager, AggTickerSer
from factor_calculator import FactorCalculator
from asq_model_old import asq_model

class MarketMakerStrategy(BaseMarketMaker):
    def __init__(self, symbol, key, secret, passphrase):
        super().__init__(symbol, key, secret, passphrase)
        self.pos = -5  # 纯头寸
        self.init_second = 121  # 预热秒数
        self.agg_ticker_manager = AggTickerManager()
        self.agg_ticker_ser = AggTickerSer(maxlen=1024)
        self.last_ticker: Ticker | None = None

        # ASQ模型参数设定
        self.sigma = 0.02972318480569305
        self.A = 4.178231911457281
        self.k = 2.086091513959453
        self.gamma = 0.01
        self.price_int = 0.01  # 合约最小价格
        self.q = 3

        # 交易参数
        self.lever = 7
        self.size = 1

        # 因子计算对象
        self.factor_calculator = FactorCalculator(self.agg_ticker_ser, max_size=1024)

        # 读取model
        self.model: LGBMRegressor = joblib.load("lgbm_model.joblib")

    async def on_tick(self, ticker: Ticker):

        # 更新agg_ticker数据
        self.agg_ticker_manager.update_ticker(ticker)

        # 秒秒时，推送数据（ts为纳秒时间戳）
        if (self.last_ticker is not None) and (ticker.ts // 1e9 != self.last_ticker.ts // 1e9):
            # 读取数据
            new_agg_ticker = self.agg_ticker_manager.agg_ticker
            self.agg_ticker_manager.re_set()

            # 放入时间序列中
            self.agg_ticker_ser.update_agg_ticker(new_agg_ticker)
            # 计算因子
            factors = self.factor_calculator.get_features()
            # print(f"预热数据数量 {self.agg_ticker_ser.ser_len}")
            # print(f"因子预热数据数量 {self.factor_calculator.factor_size}")
            # print(f"因子名称: {self.factor_calculator.feature_names}")
            # print(f"因子值: {factors}")

            # 判断数据是否预热完成
            if self.agg_ticker_ser.ser_len >= self.init_second:
                # 计算mid_price
                mid_price = (new_agg_ticker.bp_last + new_agg_ticker.ap_last) / 2
                # 预测收益率
                pre_ret = self.model.predict(np.array([factors]))[0]
                # 计算预测后的价格
                pre_mid_price = mid_price * (1 + pre_ret)

                # print(f"ask1: {new_agg_ticker.ap_last}, bid1: {new_agg_ticker.bp_last}, mid_price: {mid_price}, pre_mid_price: {pre_mid_price}")

                # 计算ASQ模型
                buy_price = pre_mid_price - asq_model.get_bid_spread(self.sigma, self.A, self.k, self.gamma, self.pos)
                sell_price = pre_mid_price + asq_model.get_ask_spread(self.sigma, self.A, self.k, self.gamma, self.pos)
                # 去除价格多余位
                buy_price = np.ceil(buy_price / self.price_int) * self.price_int
                sell_price = np.floor(sell_price / self.price_int) * self.price_int

                # 如果计算的挂单bid_price高于真实bid_price，则调整为真实bid_price
                if buy_price > ticker.bid_price:
                    buy_price = ticker.bid_price
                # 如果计算的挂单ask_price低于真实ask_price，则调整为真实ask_price
                if sell_price < ticker.ask_price:
                    sell_price = ticker.ask_price

                # 撤销之前未成交的单子
                await self.cancel_all_order()

                # 下单
                if self.pos_q <= -self.q:
                    await self.create_order(symbol=self.symbol, side='buy', size=self.size, type='limit', price=buy_price, lever=self.lever, post_only=True)
                elif self.pos_q >= self.q:
                    await self.create_order(symbol=self.symbol, side='sell', size=self.size, type='limit', price=sell_price, lever=self.lever, post_only=True)
                else:
                    await self.create_market_maker_order(symbol=self.symbol, lever=self.lever, size=self.size, price_buy=buy_price, price_sell=sell_price, post_only=True)

                # print(f"当前: bid_price: {ticker.bid_price}, ask_price: {ticker.ask_price}")
                # print(f"下单: buy_price: {buy_price}, sell_price: {sell_price}")
                # print("")
            else:
                await app_logger.info(f"等待预热{self.init_second - self.agg_ticker_ser.ser_len}s")

        # 记录为上一个ticker
        self.last_ticker = ticker

    async def on_order(self, order: Order):
        # 记录仓位
        if order.type == 'match':
            match_size = order.match_size if order.side == 'buy' else -order.match_size
            self.pos += match_size

        await app_logger.info(f"on_order: {order}")
        await app_logger.info(f"self.pos: {self.pos}, pos_q: {self.pos_q}")

    @property
    def pos_q(self):
        if self.q == 0:
            raise ValueError("b cannot be zero")
        pos_q = self.pos / self.size
        if pos_q < 0:
            return int(np.floor(pos_q))
        else:
            return int(np.ceil(pos_q))

async def main():
    symbol = 'ETHUSDTM'
    key = SB2_APIKEY.get('key')
    secret = SB2_APIKEY.get('secret')
    passphrase = SB2_APIKEY.get('passphrase')

    market_maker = MarketMakerStrategy(symbol=symbol,
                                       key=key,
                                       secret=secret,
                                       passphrase=passphrase,
                                       )
    await market_maker.run()


if __name__ == "__main__":
    # 设置日志路径
    loop = asyncio.get_event_loop()
    loop.run_until_complete(app_logger.set_error_path(ERROR_LOG_PATH))
    loop.run_until_complete(app_logger.set_info_path(INFO_LOG_PATH))
    loop.run_until_complete(main())
