
import asyncio

from kucoin_futures.common.app_logger import app_logger

from asq_alpha_mm_base_strategy import ASQAlphaMMBaseStrategy
from config import SB2_APIKEY
from config import ERROR_LOG_PATH, INFO_LOG_PATH


async def main():
    market_maker = ASQAlphaMMBaseStrategy(
        symbol='ETHUSDTM',
        key=SB2_APIKEY['key'],
        secret=SB2_APIKEY['secret'],
        passphrase=SB2_APIKEY['passphrase'],
        lever=5,
        open_size=2,
        init_second=1,
        wait_second=20,
        ml_model_path="/home/ec2-user/ML_model/lgbm_model_ETHUSDTM.pkl",
        asq_model_path="/home/ec2-user/ASQ_model/asq_model_ETHUSDTM.pkl"
    )
    await market_maker.run()

if __name__ == '__main__':
    # 设置日志路径
    loop = asyncio.get_event_loop()
    loop.run_until_complete(app_logger.set_error_path(ERROR_LOG_PATH))
    loop.run_until_complete(app_logger.set_info_path(INFO_LOG_PATH))
    loop.run_until_complete(main())