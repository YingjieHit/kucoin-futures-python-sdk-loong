
import asyncio

from kucoin_futures.common.app_logger import app_logger

from asq_beta_mm_base_strategy import ASQBetaMMBaseStrategy
from config import KC_MM_OP_APIKEY
from config import ERROR_LOG_PATH, INFO_LOG_PATH


async def main():
    market_maker = ASQBetaMMBaseStrategy(
        symbol='LINKUSDTM',
        key=KC_MM_OP_APIKEY['key'],
        secret=KC_MM_OP_APIKEY['secret'],
        passphrase=KC_MM_OP_APIKEY['passphrase'],
        lever=5,
        open_size=48,   # 12,
        init_second=1,
        ml_model_path="/home/ec2-user/ML_model/lgbm_model_LINKUSDTM.pkl",
        asq_model_path="/home/ec2-user/ASQ_model/asq_model_LINKUSDTM.pkl",
        is_debug=False,
        record_price_path="/home/ec2-user/HFT_debug_record/order_price_LINKUSDTM.csv",
        record_order_path="/home/ec2-user/HFT_debug_record/order_LINKUSDTM.csv",
    )
    await market_maker.run()

if __name__ == '__main__':
    # 设置日志路径
    loop = asyncio.get_event_loop()
    loop.run_until_complete(app_logger.set_error_path(ERROR_LOG_PATH))
    loop.run_until_complete(app_logger.set_info_path(INFO_LOG_PATH))
    loop.run_until_complete(main())
