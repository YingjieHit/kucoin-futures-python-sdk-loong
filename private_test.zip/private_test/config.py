

SB2_APIKEY = {
    "key": '65bb0ff628c3e4000110223d',
    'secret': 'c393864f-fc45-461d-a199-8d52c10978c0',
    'passphrase': 'api_4321',
}

KC_MM_TRB_APIKEY = {
    "key": '664eee88109a96000152816d',
    'secret': '60539b24-232f-4add-82b4-dc9f09eedb34',
    'passphrase': 'mmtrbapi6688',
}

KC_MM_OP_APIKEY = {
    "key": '666066f4cbdb890001b1130c',
    'secret': 'c8cf570b-fa15-43d3-846c-f841857b4aa3',
    'passphrase': 'mmopapi6688',
}


INFO_LOG_PATH = "./info.log"
ERROR_LOG_PATH = "./error.log"
ML_MODEL_DIR = "/home/ec2-user/ML_model"
ASQ_MODEL_DIR = "/home/ec2-user/ASQ_model"
