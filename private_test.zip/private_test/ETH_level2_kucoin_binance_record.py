import asyncio
import logging
import json

from kucoin_futures.client import WsToken
from kucoin_futures.ws_client import KucoinFuturesWsClient
from binance.lib.utils import config_logging
from binance.websocket.um_futures.async_websocket_client import AsyncUMFuturesWebsocketClient

config_logging(logging, logging.INFO)


class KBL2Recorder(object):
    storage_folder = "/home/ec2-user/HFT_data/Kucoin/level2Depth5"  # 设置存储文件夹的名称
    bn_symbol = 'ethusdt'
    kc_symbol = 'ETHUSDTM'

    def __init__(self):
        self.data_queue = asyncio.Queue()

        self.bn_client = None

        self.kc_ws_token = None
        self.kc_ws_client = None
        self.record_data_task = None

    async def run(self):
        self.record_data_task = asyncio.create_task(self.record_data())

        # 订阅BN
        self.bn_client = AsyncUMFuturesWebsocketClient(on_message=self.deal_bn_msg)
        await self.bn_client.start()
        await self.bn_client.partial_book_depth(symbol=self.bn_symbol, level=5, speed=100)

        # 订阅KC
        self.kc_ws_token = WsToken()
        self.kc_ws_client = await KucoinFuturesWsClient.create(None, self.kc_ws_token, self.deal_kc_msg, private=False)
        await self.kc_ws_client.subscribe(f'/contractMarket/level2Depth5:{self.kc_symbol}')

        while True:
            await asyncio.sleep(60 * 60 * 24)

    async def deal_bn_msg(self, msg: str):
        msg = json.loads(msg)
        if msg.get('e') == 'depthUpdate':
            msg['exchange'] = 'binance'
            await self.data_queue.put(msg)

    async def deal_kc_msg(self, msg):
        msg['exchange'] = 'kucoin'
        await self.data_queue.put(msg)

    async def record_data(self):
        while True:
            try:
                data = await self.data_queue.get()
                exchange = data.get('exchange')
                if exchange == 'binance':
                    print(exchange)
                    print(data)
                elif exchange == 'kucoin':
                    print(exchange)
                    print(data)
                else:
                    logging.error(f"Exchange Error: {exchange}")
            except Exception as e:
                logging.error(e)



if __name__ == '__main__':
    kb_l2_recorder = KBL2Recorder()
    asyncio.run(kb_l2_recorder.run())
