import asyncio
import ccxt.pro as ccxt


class CCXT_TestCLS(object):
    def __init__(self):
        self.exchange = ccxt.kucoinfutures()
        self.tick_task = None
        self.trade_task = None

    async def run(self):
        self.tick_task = asyncio.create_task(self.deal_tick())
        self.trade_task = asyncio.create_task(self.deal_trade())
        while True:
            await asyncio.sleep(60 * 60 * 24)


    async def deal_tick(self):
        while True:
            ticker = await self.exchange.watch_ticker('ETHUSDTM')
            print('行情数据：', ticker, "时间", ticker['datetime'])

    async def deal_trade(self):
        while True:
            trade = await self.exchange.watch_trades('ETHUSDTM')
            print('成交数据:', trade, '时间', trade[0]['datetime'])


if __name__ == '__main__':
    ccxt_test = CCXT_TestCLS()
    asyncio.run(ccxt_test.run())
