import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.stattools import acf

# 生成一个示例数据
np.random.seed(42)
data = np.random.randn(100)  # 100个随机数

# 计算自相关系数
lag_acf = acf(data, nlags=20, fft=True)

print("Autocorrelation coefficients:", lag_acf)

import os
print("当前工作目录：", os.getcwd())
